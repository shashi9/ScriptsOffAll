import subprocess
import json
import openpyxl
import logging
from colorama import init, Fore, Style
import os
from datetime import datetime
import requests # Import the requests library for fetching headers

# Initialize colorama for colored console output
init(autoreset=True)

# Configure logging to display debug, info, warning, and error messages with timestamps
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def run_tool(tool, target, vulnerabilities, proxy=None):
    """
    Runs a specified security tool (testssl, nuclei, or custom 'headers' fetcher)
    against a target URL for given vulnerabilities.
    Outputs results to a JSON file, appending to it if it already exists.

    Args:
        tool (str): The name of the tool to run ('testssl', 'nuclei', 'headers').
        target (str): The URL or target for the scan.
        vulnerabilities (list): A list of vulnerability IDs or types to check for.
        proxy (str, optional): Proxy address for tools that support it. Defaults to None.

    Returns:
        dict: A dictionary where keys are vulnerability IDs and values are
              paths to the output JSON files, or None if an error occurred.
    """
    result_files = {}
    for vuln in vulnerabilities:
        if not vuln:
            continue

        # Define the main output JSON file name for this tool and vulnerability
        json_output_file = f"{target.replace('://', '_').replace('/', '_')}_{vuln}_{tool}_output.json"
        
        # --- Handle 'headers' tool directly in Python using requests ---
        if tool == 'headers':
            logging.debug(f"Fetching headers using requests for: {target} (Vulnerability: {vuln})")
            
            headers_data = {}
            try:
                # Use requests.head() to get only headers, which is efficient.
                # allow_redirects=True ensures it follows redirects to the final URL.
                # timeout is crucial to prevent the script from hanging.
                response = requests.head(target, allow_redirects=True, timeout=15) 
                response.raise_for_status() # Raise an exception for HTTP errors (4xx or 5xx)
                headers_data = dict(response.headers) # Convert headers to a standard dictionary
                logging.info(f"Successfully fetched headers for {target}")
            except requests.exceptions.HTTPError as e:
                logging.error(f"HTTP error fetching headers for {target}: {e.response.status_code} - {e.response.reason}")
                headers_data = {"error": f"HTTP Error: {e.response.status_code} - {e.response.reason}"}
            except requests.exceptions.ConnectionError as e:
                logging.error(f"Connection error fetching headers for {target}: {e}")
                headers_data = {"error": f"Connection Error: {e}"}
            except requests.exceptions.Timeout as e:
                logging.error(f"Timeout error fetching headers for {target}: {e}")
                headers_data = {"error": f"Timeout Error: {e}"}
            except requests.exceptions.RequestException as e:
                logging.error(f"An unexpected requests error occurred for {target}: {e}")
                headers_data = {"error": f"Request Exception: {e}"}
            except Exception as e:
                logging.error(f"An general error occurred fetching headers for {target}: {e}")
                headers_data = {"error": f"General Error: {e}"}

            # Now, integrate this headers_data with the existing JSON file appending logic
            all_scans_data = []

            # 1. Read existing data from the main output file (if it exists and is valid)
            if os.path.exists(json_output_file) and os.path.getsize(json_output_file) > 0:
                try:
                    with open(json_output_file, 'r') as f:
                        existing_data = json.load(f)
                        if isinstance(existing_data, list):
                            all_scans_data.extend(existing_data)
                        else:
                            # If existing file is not an array, treat it as a single previous scan
                            all_scans_data.append(existing_data)
                            logging.warning(f"Existing file {json_output_file} was not a JSON array. Converting to array format.")
                except json.JSONDecodeError as e:
                    logging.error(f"JSON decode error in existing file {json_output_file}: {e}. Starting with fresh data for this run.")
                except Exception as e:
                    logging.error(f"An error occurred reading {json_output_file}: {e}. Starting with fresh data for this run.")

            # Add the new headers scan result with a timestamp
            current_scan_entry = {
                "target_url": target,
                "headers_found": headers_data,
                "_scan_timestamp": datetime.now().isoformat(),
                "vulnerability_check_context": vuln # Useful to know which check this was for
            }
            all_scans_data.append(current_scan_entry)

            # Write the combined data back to the main output file
            if all_scans_data:
                try:
                    with open(json_output_file, 'w') as f:
                        json.dump(all_scans_data, f, indent=2) # indent=2 for pretty printing
                    logging.info(f"Successfully updated/appended headers output for {vuln} to {json_output_file}")
                    result_files[vuln] = json_output_file
                except Exception as e:
                    logging.error(f"Error writing combined JSON for headers to {json_output_file}: {e}")
                    result_files[vuln] = None
            else:
                # If no data to write (e.g., first run, and header fetch failed completely)
                result_files[vuln] = None
                if os.path.exists(json_output_file):
                    try:
                        os.remove(json_output_file)
                        logging.info(f"Removed empty/invalid {json_output_file}")
                    except OSError as e:
                        logging.error(f"Error removing empty/invalid {json_output_file}: {e}")
            
            continue # Move to the next vulnerability for this target or next target

        # --- Handle testssl and nuclei using subprocess ---
        # Define a temporary JSON file for the current tool run (for subprocess-based tools)
        temp_json_file = f"temp_{os.path.basename(json_output_file)}"
        
        command = []
        if tool == 'testssl':
            command = ['testssl', '--jsonfile', temp_json_file, f'--{vuln}', target]
        elif tool == 'nuclei':
            # Changed -jsonl to -json for easier array handling in the appending logic
            command = ['nuclei', '-id', vuln, '-jsonl', '-o', temp_json_file, '-u', target, '>>', temp_json_file] 
            if proxy:
                command += ['-p', proxy]
        else:
            # This 'else' block catches any other tools not explicitly handled
            logging.error(f"Unknown tool: {tool}")
            result_files[vuln] = None
            continue

        logging.debug(f"Running {tool} command: {' '.join(command)}")
        process = subprocess.run(command, capture_output=True, text=True) 

        if process.returncode != 0:
            logging.error(f"{tool} command for {vuln} failed with return code {process.returncode}.")
            if process.stdout:
                logging.error(f"Stdout: {process.stdout}")
            if process.stderr:
                logging.error(f"Stderr: {process.stderr}")
            result_files[vuln] = None
            # Clean up temp file if command failed and it was created
            if os.path.exists(temp_json_file):
                try:
                    os.remove(temp_json_file)
                    logging.info(f"{temp_json_file} has been deleted due to command failure.")
                except OSError as e:
                    logging.error(f"Error: {temp_json_file} could not be deleted after failure. {e}")
            continue # Move to next vulnerability if current one failed

        # --- JSON Appending Logic for subprocess-based tools ---
        all_scans_data = [] 

        # 1. Read existing data from the main output file (if it exists and is valid)
        if os.path.exists(json_output_file) and os.path.getsize(json_output_file) > 0:
            try:
                with open(json_output_file, 'r') as f:
                    existing_data = json.load(f)
                    if isinstance(existing_data, list):
                        all_scans_data.extend(existing_data)
                    else:
                        all_scans_data.append(existing_data)
                        logging.warning(f"Existing file {json_output_file} was not a JSON array. Converting to array format.")
            except json.JSONDecodeError as e:
                logging.error(f"JSON decode error in existing file {json_output_file}: {e}. Starting with fresh data for this run.")
            except Exception as e:
                logging.error(f"An error occurred reading {json_output_file}: {e}. Starting with fresh data for this run.")

        # 2. Read new data from the temporary file
        if os.path.exists(temp_json_file) and os.path.getsize(temp_json_file) > 0:
            try:
                with open(temp_json_file, 'r') as f:
                    new_data = json.load(f)

                # Add a timestamp to the new scan data for better context
                if isinstance(new_data, dict):
                    new_data["_scan_timestamp"] = datetime.now().isoformat()
                    all_scans_data.append(new_data)
                elif isinstance(new_data, list):
                    for item in new_data:
                        if isinstance(item, dict):
                            item["_scan_timestamp"] = datetime.now().isoformat()
                        all_scans_data.append(item)
                else:
                    logging.warning(f"Unexpected JSON format from {tool} in {temp_json_file}: {type(new_data)}. Skipping append for this data.")

            except json.JSONDecodeError as e:
                logging.error(f"JSON decode error in temporary file {temp_json_file}: {e}. Skipping append for this data.")
            except Exception as e:
                logging.error(f"An error occurred processing {temp_json_file}: {e}. Skipping append for this data.")
            finally:
                # Clean up the temporary file
                try:
                    os.remove(temp_json_file)
                except OSError as e:
                    logging.error(f"Error: {temp_json_file} could not be deleted after processing. {e}")
        else:
            logging.warning(f"Temporary output file {temp_json_file} was empty or not created for {tool} {vuln}.")

        # 3. Write the combined data back to the main output file
        if all_scans_data: 
            try:
                with open(json_output_file, 'w') as f:
                    json.dump(all_scans_data, f, indent=2) 
                logging.info(f"Successfully updated/appended {tool} output for {vuln} to {json_output_file}")
                result_files[vuln] = json_output_file
            except Exception as e:
                logging.error(f"Error writing combined JSON to {json_output_file}: {e}")
                result_files[vuln] = None
        else:
            if os.path.exists(json_output_file) and os.path.getsize(json_output_file) > 0:
                result_files[vuln] = json_output_file
            else:
                result_files[vuln] = None
                if os.path.exists(json_output_file):
                    try:
                        os.remove(json_output_file)
                        logging.info(f"Removed empty/invalid {json_output_file}")
                    except OSError as e:
                        logging.error(f"Error removing empty/invalid {json_output_file}: {e}")

    return result_files

def check_vulnerability(json_file, vulnerability_ids, test_case, tool):
    """
    Checks the vulnerability status based on the JSON output file and tool type.

    Args:
        json_file (str): Path to the JSON output file.
        vulnerability_ids (list): List of vulnerability IDs to check against.
        test_case (str): The name of the test case.
        tool (str): The tool that generated the JSON file ('testssl', 'nuclei', 'headers').

    Returns:
        str: "Passed", "Failed", or "Error".
    """
    if not os.path.exists(json_file) or os.path.getsize(json_file) == 0:
        logging.error(f"{json_file} is empty or does not exist")
        # If the file is empty or doesn't exist, it likely means no findings or an error occurred.
        # For security checks, if no findings, it's often a "Passed" unless an error prevented the scan.
        return "Error" if tool == 'testssl' else "Passed" # testssl might error if it can't run; nuclei/headers often empty if no issue

    try:
        with open(json_file, 'r') as f:
            data = json.load(f)

        if not isinstance(data, list):
            logging.error(f"Expected JSON array in {json_file}, but found {type(data)}. Cannot process.")
            return "Error"

        # Now, `data` is a list of scan results.
        # Each check_tool_vulnerability function will iterate through this list.
        if tool == 'testssl':
            return check_testssl_vulnerability(data, vulnerability_ids, test_case)
        elif tool == 'nuclei':
            return check_nuclei_vulnerability(data)
        elif tool == 'headers':
            return check_headers_vulnerability(data, vulnerability_ids, test_case)
        else:
            logging.error(f"Unknown tool for vulnerability check: {tool}")
            return "Error"
    except json.JSONDecodeError as e:
        logging.error(f"JSON decode error in {tool} for file {json_file}: {e}")
        return "Error"
    except Exception as e:
        logging.error(f"An error occurred while checking {tool} JSON output for {json_file}: {e}")
        return "Error"

def check_testssl_vulnerability(data_list, vulnerability_ids, test_case):
    """
    Checks testssl vulnerabilities from a list of scan results.
    Returns "Failed" if any scan indicates a vulnerability matching the IDs.

    Args:
        data_list (list): A list of dictionaries, where each dict is a testssl scan result.
        vulnerability_ids (list): List of specific vulnerability IDs to look for.
        test_case (str): The name of the test case (for logging context).

    Returns:
        str: "Passed" or "Failed".
    """
    for scan_result in data_list:
        # This is an illustrative example. You need to adapt this based on your
        # specific testssl JSON output structure and what constitutes a "Failed" status.
        # For example, testssl's JSON might have a 'vulnerabilities' key
        # containing a list of findings, each with an 'id' and 'severity'.
        if 'vulnerabilities' in scan_result and isinstance(scan_result['vulnerabilities'], list):
            for vuln_entry in scan_result['vulnerabilities']:
                if isinstance(vuln_entry, dict) and vuln_entry.get('id') in vulnerability_ids:
                    # You might also want to check severity: and vuln_entry.get('severity') in ['CRITICAL', 'HIGH']
                    logging.info(f"Testssl: Found vulnerability '{vuln_entry.get('id')}' for test case '{test_case}'.")
                    return "Failed"
        # Add more specific checks here based on your testssl JSON structure
        # For example, if you're checking for specific protocol versions or cipher suites directly
        # if 'protocols' in scan_result and 'TLSv1.0' in scan_result['protocols']: return "Failed"

    return "Passed" # If no scan indicates a failure

def check_nuclei_vulnerability(data_list):
    """
    Checks nuclei vulnerabilities from a list of scan results.
    Returns "Failed" if the data_list is not empty (indicating findings).

    Args:
        data_list (list): A list of dictionaries, where each dict is a nuclei finding.

    Returns:
        str: "Passed" or "Failed".
    """
    if data_list:
        # If the list of findings from nuclei is not empty, it means vulnerabilities were found.
        logging.info(f"Nuclei: Found {len(data_list)} findings.")
        return "Failed"
    return "Passed"

def check_headers_vulnerability(data_list, vulnerability_ids, test_case):
    """
    Checks server headers for vulnerabilities from a list of header scan results.
    This function needs to be customized based on what specific headers
    you are checking for (e.g., absence of security headers, presence of sensitive headers).

    Args:
        data_list (list): A list of dictionaries, where each dict contains header data.
                          Each dict will have a 'headers_found' key.
        vulnerability_ids (list): List of specific header-related checks (e.g., 'missing-hsts', 'x-powered-by').
        test_case (str): The name of the test case (for logging context).

    Returns:
        str: "Passed" or "Failed".
    """
    for scan_result in data_list:
        headers = scan_result.get('headers_found', {})
        
        # If there was an error fetching headers, consider it "NA" or "Error" for this specific scan
        if "error" in headers:
            logging.warning(f"Headers check for {scan_result.get('target_url')}: Error in fetching headers: {headers['error']}")
            # You might want to return "NA" or "Error" here if any single scan fails to fetch headers.
            # For now, we'll let it pass if other scans are fine, but log the issue.
            continue

        # --- Implement your specific header checks here ---
        # Example: Check for missing HSTS (Strict-Transport-Security) header
        if 'missing-hsts' in vulnerability_ids:
            if 'Strict-Transport-Security' not in headers:
                logging.info(f"Headers: Missing Strict-Transport-Security header for {scan_result.get('target_url')}.")
                return "Failed"

        # Example: Check for X-Powered-By header (often reveals server technology)
        if 'x-powered-by' in vulnerability_ids:
            if 'X-Powered-By' in headers:
                logging.info(f"Headers: Found X-Powered-By header ('{headers['X-Powered-By']}') for {scan_result.get('target_url')}.")
                # This might be a "Failed" depending on your security policy
                return "Failed" # Example: If presence of this header is a failure

        # Example: Check for X-Content-Type-Options: nosniff
        if 'x-content-type-options-nosniff' in vulnerability_ids:
            if headers.get('X-Content-Type-Options', '').lower() != 'nosniff':
                logging.info(f"Headers: Missing or incorrect X-Content-Type-Options header for {scan_result.get('target_url')}.")
                return "Failed"

        # Example: Check for Content-Security-Policy header
        if 'missing-csp' in vulnerability_ids:
            if 'Content-Security-Policy' not in headers:
                logging.info(f"Headers: Missing Content-Security-Policy header for {scan_result.get('target_url')}.")
                return "Failed"

        # Add more header checks as needed based on your 'vulnerability_ids'
        # e.g., 'x-frame-options', 'referrer-policy', 'permissions-policy' etc.

    return "Passed" # If no header check indicates a failure across all scans

def process_targets(urls_file, test_cases_file, input_excel, output_excel, proxy=None):
    """
    Reads target URLs and test cases, runs appropriate tools, and updates an Excel report.

    Args:
        urls_file (str): Path to a file containing URLs (one per line).
        test_cases_file (str): Path to an Excel file mapping test cases to tools and vulnerabilities.
        input_excel (str): Path to the input Excel report template.
        output_excel (str): Path to save the updated Excel report.
        proxy (str, optional): Proxy address. Defaults to None.
    """
    with open(urls_file, 'r') as file:
        targets = file.read().splitlines()
    
    # Load test cases from Excel
    wb_cases = openpyxl.load_workbook(test_cases_file)
    sheet_cases = wb_cases.active
    test_case_tool_mapping = {sheet_cases.cell(row=row, column=1).value: sheet_cases.cell(row=row, column=2).value for row in range(2, sheet_cases.max_row + 1)}
    test_case_vulnerability_mapping = {sheet_cases.cell(row=row, column=1).value: sheet_cases.cell(row=row, column=3).value.split(',') if sheet_cases.cell(row=row, column=3).value else [] for row in range(2, sheet_cases.max_row + 1)}

    # Load the main input Excel report
    wb = openpyxl.load_workbook(input_excel)
    sheet = wb.active
    
    # Find row indices for each test case in the input Excel
    test_case_indices = {cell.value: cell.row for cell in sheet['D'] if cell.value in test_case_tool_mapping}

    # Find column indices for Status, Failed URLs, Passed URLs, NA URLs
    status_column = next((col for col in range(1, sheet.max_column + 1) if sheet.cell(row=1, column=col).value == 'Status'), sheet.max_column + 1)
    failed_urls_column = next((col for col in range(1, sheet.max_column + 1) if sheet.cell(row=1, column=col).value == 'Failed URLs'), sheet.max_column + 1)
    passed_urls_column = next((col for col in range(1, sheet.max_column + 1) if sheet.cell(row=1, column=col).value == 'Passed URLs'), sheet.max_column + 1)
    na_urls_column = next((col for col in range(1, sheet.max_column + 1) if sheet.cell(row=1, column=col).value == 'NA URLs'), sheet.max_column + 1)

    # Iterate through each test case and target
    for test_case, tool_name in test_case_tool_mapping.items():
        vulnerabilities = test_case_vulnerability_mapping.get(test_case, [])
        for target in targets:
            # Run the appropriate tool and get the paths to the JSON result files
            result_files = run_tool(tool_name, target, vulnerabilities, proxy)
            
            # Process results for each vulnerability checked by the tool
            for vuln_id_context, json_file_path in result_files.items():
                if json_file_path:
                    # Check the vulnerability status from the JSON file
                    result = check_vulnerability(json_file_path, vulnerabilities, test_case, tool_name)
                elif json_file_path is None:
                    # This case means the tool command failed to produce any valid output,
                    # or there was an error during the append process.
                    result = "NA" 
                else:
                    result = "Error" 
                
                # Update the Excel sheet with the result
                if test_case in test_case_indices:
                    update_excel(sheet, test_case_indices[test_case], status_column, failed_urls_column, passed_urls_column, na_urls_column, result, target)

    # Save the updated Excel workbook
    wb.save(output_excel)
    logging.info(f"Results written to {output_excel}")

def update_excel(sheet, row_index, status_column, failed_urls_column, passed_urls_column, na_urls_column, result, target):
    """
    Updates the Excel sheet with the scan result for a specific test case and target.

    Args:
        sheet (openpyxl.worksheet.worksheet.Worksheet): The active Excel worksheet.
        row_index (int): The row number for the current test case.
        status_column (int): Column index for the 'Status' column.
        failed_urls_column (int): Column index for 'Failed URLs'.
        passed_urls_column (int): Column index for 'Passed URLs'.
        na_urls_column (int): Column index for 'NA URLs'.
        result (str): The scan result ("Passed", "Failed", "NA", "Error").
        target (str): The URL that was scanned.
    """
    current_status = sheet.cell(row=row_index, column=status_column).value
    current_failed_urls = sheet.cell(row=row_index, column=failed_urls_column).value
    current_passed_urls = sheet.cell(row=row_index, column=passed_urls_column).value
    current_na_urls = sheet.cell(row=row_index, column=na_urls_column).value

    if result == 'Failed':
        # If any scan fails, the overall status for the test case is "Failed"
        if current_status != 'Failed':
            sheet.cell(row=row_index, column=status_column, value='Failed')
        update_cell(sheet, row_index, failed_urls_column, current_failed_urls, target)
    elif result == 'Passed':
        # Only update status to "Passed" if it's not already "Failed"
        if current_status not in ['Failed', 'Passed']: 
            sheet.cell(row=row_index, column=status_column, value='Passed')
        update_cell(sheet, row_index, passed_urls_column, current_passed_urls, target)
    elif result == 'NA':
        # Only set "NA" if not already "Failed" or "Passed"
        if current_status not in ['Failed', 'Passed']: 
            sheet.cell(row=row_index, column=status_column, value='NA')
        update_cell(sheet, row_index, na_urls_column, current_na_urls, target)
    elif result == 'Error': 
        # If an error occurs, update status to "Error" if not already "Failed" or "Passed"
        if current_status not in ['Failed', 'Passed', 'Error']: 
            sheet.cell(row=row_index, column=status_column, value='Error')
        update_cell(sheet, row_index, na_urls_column, current_na_urls, f"Error: {target}") 


def update_cell(sheet, row, column, current_value, new_value):
    """
    Helper function to update an Excel cell, appending new values if the cell
    already contains data, and avoiding duplicates.

    Args:
        sheet (openpyxl.worksheet.worksheet.Worksheet): The active Excel worksheet.
        row (int): Row index.
        column (int): Column index.
        current_value (str): The current value of the cell.
        new_value (str): The new value to append.
    """
    if current_value:
        # Split current value by comma and strip whitespace to check for duplicates
        existing_items = [item.strip() for item in str(current_value).split(',')]
        if new_value not in existing_items:
            sheet.cell(row=row, column=column, value=f"{current_value}, {new_value}")
    else:
        sheet.cell(row=row, column=column, value=new_value)

if __name__ == "__main__":
    # Prompt user for file paths
    urls_file = input(Fore.CYAN + "Enter the path to the URLs file: " + Style.RESET_ALL)
    test_cases_file = input(Fore.CYAN + "Enter the path to the test cases Excel file: " + Style.RESET_ALL)
    input_excel = input(Fore.CYAN + "Enter the path to the input Excel file: " + Style.RESET_ALL)
    output_excel = input(Fore.CYAN + "Enter the path to the output Excel file: " + Style.RESET_ALL)
    proxy = input(Fore.CYAN + "Enter the proxy (or leave blank if not using): " + Style.RESET_ALL)

    # Start the main processing
    process_targets(urls_file, test_cases_file, input_excel, output_excel, proxy if proxy else None)